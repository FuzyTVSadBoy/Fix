#include "GDBServer.hpp"
#include "../Emulator.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <cstdio>
#include <sstream>
#include <SDL_log.h>

GDBServer::GDBServer(casioemu::Emulator* emu, int port)
    : m_emulator(emu), m_port(port), m_running(false), m_server_socket(INVALID_SOCKET), m_clientConnected(false)
{
}

GDBServer::~GDBServer()
{
    Stop();
}

bool GDBServer::Start()
{
    if (m_running)
        return true;

#ifdef _WIN32
    WSADATA wsaData;
    int result = WSAStartup(MAKEWORD(2, 2), &wsaData);
    if (result != 0) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "GDBServer: WSAStartup failed: %d", result);
        return false;
    }
#endif

    m_server_socket = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (m_server_socket == INVALID_SOCKET) {
#ifdef _WIN32
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "GDBServer: Error at socket(): %d", WSAGetLastError());
#else
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "GDBServer: Error at socket(): %s", strerror(errno));
#endif
#ifdef _WIN32
        WSACleanup();
#endif
        return false;
    }

    sockaddr_in service;
    service.sin_family = AF_INET;
    service.sin_addr.s_addr = htonl(INADDR_ANY); 
    service.sin_port = htons(m_port);

    if (bind(m_server_socket, (sockaddr*)&service, sizeof(service)) == SOCKET_ERROR) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "GDBServer: bind() to port %d failed. Pls check INTERNET permission. Error: %s", m_port, strerror(errno));
        close_socket_helper(m_server_socket);
#ifdef _WIN32
        WSACleanup();
#endif
        return false;
    }

    if (listen(m_server_socket, 1) == SOCKET_ERROR) {
        SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "GDBServer: listen() failed. Error: %s", strerror(errno));
        close_socket_helper(m_server_socket);
#ifdef _WIN32
        WSACleanup();
#endif
        return false;
    }
    m_running = true;
    m_thread = std::thread(&GDBServer::ServerThread, this);
    SDL_Log("GDB Server listening on port %d", m_port);
    return true;
}

void GDBServer::Stop()
{
    if (!m_running) return;
    m_running = false;
    if (m_server_socket != INVALID_SOCKET) {
#ifdef _WIN32
        shutdown(m_server_socket, SD_BOTH);
#else
        shutdown(m_server_socket, SHUT_RDWR);
#endif
        close_socket_helper(m_server_socket);
        m_server_socket = INVALID_SOCKET;
    }
    if (m_thread.joinable()) {
        m_thread.join();
    }
#ifdef _WIN32
    WSACleanup();
#endif
    SDL_Log("GDB Server stopped.");
}

void GDBServer::ServerThread()
{
    while (m_running)
    {
        socket_t client_socket = accept(m_server_socket, NULL, NULL);
        if (client_socket == INVALID_SOCKET)
        {
            if (m_running) {
                 SDL_LogError(SDL_LOG_CATEGORY_APPLICATION, "GDBServer: accept() failed or was interrupted.");
            }
            break;
        }

        m_clientConnected = true;
        HandleConnection(client_socket);
        m_clientConnected = false;
        close_socket_helper(client_socket);
    }
}

void GDBServer::HandleConnection(socket_t client_socket)
{
    SDL_Log("GDB client connected.");
    std::string buffer;
    char c;
    
    send(client_socket, "+", 1, 0);

    while (true)
    {
        int bytesRead = recv(client_socket, &c, 1, 0);
        if (bytesRead <= 0) {
            break;
        }

        if (c == '$')
        {
            buffer.clear();
            while (recv(client_socket, &c, 1, 0) > 0 && c != '#')
            {
                buffer += c;
            }

            char checksum_str[3];
            if (recv(client_socket, checksum_str, 2, 0) == 2)
            {
                checksum_str[2] = '\0';
                unsigned int received_checksum;
                sscanf(checksum_str, "%x", &received_checksum);

                unsigned int calculated_checksum = 0;
                for (char ch : buffer)
                {
                    calculated_checksum = (calculated_checksum + (unsigned char)ch) % 256;
                }

                if (received_checksum == calculated_checksum)
                {
                    send(client_socket, "+", 1, 0); // ACK
                    ProcessPacket(client_socket, buffer);
                }
                else
                {
                    send(client_socket, "-", 1, 0); // NAK
                }
            } else {
                break;
            }
        }
    }
    SDL_Log("GDB client disconnected.");
}

void GDBServer::ProcessPacket(socket_t client_socket, const std::string& packet_data)
{
    if (packet_data.rfind("qSupported", 0) == 0)
    {
        const char* response_data = "PacketSize=400";
        
        std::string packet = "$";
        packet += response_data;
        packet += "#";

        unsigned int checksum = 0;
        for (char ch : std::string(response_data))
        {
            checksum = (checksum + (unsigned char)ch) % 256;
        }

        char checksum_str[3];
        snprintf(checksum_str, sizeof(checksum_str), "%02x", checksum);
        packet += checksum_str;

        send(client_socket, packet.c_str(), packet.length(), 0);
    }
    else
    {
        send(client_socket, "$#00", 4, 0);
    }
}

std::string GDBServer::GetStatus() const
{
    if (!m_running)
    {
        return "Stopped";
    }
    else if (m_clientConnected)
    {
        return "Client Connected";
    }
    else
    {
        return "Listening";
    }
}

int GDBServer::GetPort() const
{
    return m_port;
}

void GDBServer::SetPort(int port)
{
    if (!m_running) {
        m_port = port;
    }
}