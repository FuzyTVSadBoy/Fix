﻿#pragma once
#include <Binary.h>
// TODO
class Settings {
public:
	std::string locale;
	std::string recently_used[5];

};