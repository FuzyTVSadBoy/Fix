﻿#pragma once
namespace casioemu {
	class Peripheral* CreateScreen(class Emulator& emulator);
}