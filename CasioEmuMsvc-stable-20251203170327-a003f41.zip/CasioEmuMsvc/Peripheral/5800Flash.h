﻿#pragma once
namespace casioemu {
	class Peripheral* CreateFx5800Flash(class Emulator& emu);
}