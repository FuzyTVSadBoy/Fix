﻿#pragma once
namespace casioemu {
	class Peripheral* CreateRtc(class Emulator& emu);
}