﻿#pragma once
namespace casioemu {
	class Peripheral* CreateFlash(class Emulator& emu);
}