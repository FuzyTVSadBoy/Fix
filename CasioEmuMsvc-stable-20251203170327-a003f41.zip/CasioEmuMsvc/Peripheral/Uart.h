﻿#pragma once
#include <Peripheral.hpp>
namespace casioemu{
	Peripheral* CreateUart(Emulator& emu);
} // namespace casioemu