﻿#pragma once
namespace casioemu {
	class Peripheral* CreateWatchdog(class Emulator& emu);
}