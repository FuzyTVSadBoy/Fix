﻿#pragma once
namespace casioemu {
	class Peripheral* CreateTimerBaseCounter(class Emulator& emu);
}