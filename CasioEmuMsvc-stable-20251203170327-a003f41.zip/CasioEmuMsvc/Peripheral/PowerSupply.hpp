﻿#pragma once
namespace casioemu {
	class Peripheral* CreatePowerSupply(class Emulator& emu);
}