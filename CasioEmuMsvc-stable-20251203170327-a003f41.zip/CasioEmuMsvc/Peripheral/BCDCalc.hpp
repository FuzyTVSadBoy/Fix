﻿#pragma once
namespace casioemu {
	class Peripheral* CreateBcdCalc(class Emulator& emu);
}