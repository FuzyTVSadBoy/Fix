﻿#pragma once
namespace casioemu {
	class Peripheral* CreateRomWindow(class Emulator& emu);
}