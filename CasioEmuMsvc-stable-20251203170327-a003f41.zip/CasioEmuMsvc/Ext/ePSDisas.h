#pragma once
char* decodeeps(char* rom, int pc, bool& l);