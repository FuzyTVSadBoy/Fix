﻿#pragma once

int Measure(int ucs4);
