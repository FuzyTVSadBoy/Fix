﻿#include "Localization.h"
Localization g_local;