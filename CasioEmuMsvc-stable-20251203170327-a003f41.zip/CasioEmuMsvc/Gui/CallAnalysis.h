﻿#pragma once
#include "Ui.hpp"

UIWindow* CreateCallAnalysisWindow();