﻿#pragma once
#include "Ui.hpp"
#include <vector>

std::vector<UIWindow*> GetEditors();