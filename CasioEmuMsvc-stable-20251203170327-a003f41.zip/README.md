# CasioEmuMsvc

An emulator for nX-U16/100 MCU (and nX-U8/100 MCU as well).

With debugger and built-in disassembler.

# Usage

* Download Visual Studio 2022 (or Build Tools)

* Clone this repo

* Build with VS or using `msbuild`

# Fixes for specific GPUs

You might experience crashes on specific hardwares, try this if upgrading a GPU driver didn't help.

```bat
set SDL_RENDER_DRIVER=opengl
CasioEmuMsvc.exe
```

# Discord&Feedback

https://discord.gg/NM39VPdJTf

mailto:telecomadm1919@gmail.com
