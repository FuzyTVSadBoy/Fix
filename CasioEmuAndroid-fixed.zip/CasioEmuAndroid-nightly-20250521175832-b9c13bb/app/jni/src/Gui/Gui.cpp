int RebuildFont_Requested = 0;
float RebuildFont_Scale = 0;