#pragma once
#include "Ui.hpp"
UIWindow* CreateBitmapViewer();