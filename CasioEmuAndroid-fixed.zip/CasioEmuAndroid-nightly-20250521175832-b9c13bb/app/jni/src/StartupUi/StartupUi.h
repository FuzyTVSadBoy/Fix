#pragma once
#include <string>
std::string sui_loop();