﻿#pragma once
namespace casioemu {
	class Peripheral* CreateBuzzerDriver(class Emulator& emu);
}