﻿#pragma once
namespace casioemu {
	class Peripheral* CreateStbCtrl(class Emulator& emu);
}