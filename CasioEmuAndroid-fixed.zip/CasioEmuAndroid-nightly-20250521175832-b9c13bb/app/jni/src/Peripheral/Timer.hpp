﻿#pragma once
namespace casioemu {
	class Peripheral* CreateTimer(class Emulator& emu);
}