﻿#pragma once
namespace casioemu {
	class Peripheral* CreateKeyboard(class Emulator& emu);
}