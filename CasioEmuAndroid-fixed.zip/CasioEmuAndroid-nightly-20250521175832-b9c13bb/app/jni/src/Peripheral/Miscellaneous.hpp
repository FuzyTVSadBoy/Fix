﻿#pragma once
namespace casioemu {
	class Peripheral* CreateMiscellaneous(class Emulator& emu);
}