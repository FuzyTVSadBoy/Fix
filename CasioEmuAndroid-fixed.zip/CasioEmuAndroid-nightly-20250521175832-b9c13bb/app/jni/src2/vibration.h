//
// Created by 15874 on 2024/8/9.
//

#ifndef ANDROID_PROJECT_VIBRATION_H
#define ANDROID_PROJECT_VIBRATION_H


class Vibration {
public:
    static void vibrate(long milliseconds);
};

#endif //ANDROID_PROJECT_VIBRATION_H
