﻿#pragma once
namespace casioemu {
	class Peripheral* CreateBatteryBackedRAM(class Emulator& emu);
}